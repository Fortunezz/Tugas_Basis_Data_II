</div>
</div>

<script src="assets/vendor/js/vendor.bundle.base.js"></script>
<script src="assets/js/off-canvas.js"></script>
<script src="assets/js/hoverable-collapse.js"></script>
<script src="assets/js/template.js"></script>
<script src="assets/js/dashboard.js"></script>
<script src="assets/js/Chart.roundedBarCharts.js"></script>
</body>

</html>