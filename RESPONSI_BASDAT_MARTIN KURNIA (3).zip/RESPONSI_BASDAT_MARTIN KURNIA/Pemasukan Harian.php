<?php 
include_once("header.php");
require_once("koneksi.php");
require_once("fungsi.php");
?>
<style>
.btn-primary {
  background-color: #4B49AC;
}

.btn-succes {
  background-color: #4b974b;
}

table {
  text-align: center;
}

.thead-primary {
  background-color: #17a2b8;
  color: white;
}
</style>
<!-- Page Content  -->
<div class="main-panel">
  <div id="content" class="p-4 p-md-5">

    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container-fluid">
        <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse"
          data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
          aria-label="Toggle navigation">
          <i class="fa fa-bars"></i>
        </button>

      </div>
      <div class="collapse navbar-collapse" id="navbarSupportedContent" style="color: white; ">
        <div class="nav navbar-nav ml-auto" class="nav-link" class="header-right">
          <form action="" method="post" class="form-inline  ">
            <div class="input-group" class="input-group-append">
              <input class="form-control mr-sm-2" type="text" name="keyword" placeholder="Search" autocomplete="off"
                autofocus>
              <button type="submit" name="cari" class="btn btn-success">
                <span><i class="fa fa-search" aria-hidden="true"></i>Cari</button></span>
            </div>
          </form>
        </div>
      </div>
    </nav>

    <!--Menampilkan judul untuk web ini-->
    <br>
    <h1 class="display-4">Halaman Header Bayar</h1>
    <hr>
    <!--Membuat tabel untuk wadah data pada database-->
    <!-- <table class="table table-striped" > -->
    <table id="example" class="table table-striped table-bordered table-hover" style="width:100%">

      <!--Bagian head tabel-->
      <thead class="thead-primary">
        <tr align="center">
          <th scope="col">No Nota</th>
          <th scope="col">Tanggal</th>
          <th scope="col">Total Pembelian</th>
        </tr>
      </thead>

      <!--Memanggil isi dari data pada tabel data_keluarga-->
      <!--Terdapat dua action yang memiliki fungsi untuk hapus dan ubah-->
      <?php
        $batas = 3;
        $halaman = @$_GET['halaman'];
        if (empty($halaman)) {
            $posisi = 0;
            $halaman = 1;
        } else {
            $posisi = ($halaman - 1) * $batas;
        }


        $data = mysqli_query($conn, "SELECT * FROM header_bayar LIMIT $posisi, $batas");
        $no = 1 + $posisi;

        //  untuk pencarian data
        if (isset($_POST['cari'])) {
            $keyword = $_POST['keyword'];
            $data = mysqli_query($conn, "SELECT * FROM header_bayar WHERE sisa_bayar LIKE '%$keyword%' OR no_nota
                                LIKE '%$keyword%' LIMIT $posisi, $batas");
        } else {
            $data = mysqli_query($conn, "SELECT * FROM header_bayar LIMIT $posisi, $batas");
        }
        while ($row = mysqli_fetch_array($data)) {
        ?>

      <tr>
        <td>
          <center><?php echo $row['no_nota'] ?></center>
        </td>
        <td>
          <center><?php echo $row['tanggal'] ?></center>
        </td>
        <td>
          <center>Rp.<?php echo number_format($row['total_pembelian'])?></center>
        </td>
      </tr>


      <?php
            $no++;
        }


        ?>

    </table>
    <br>
    <?php
    $query2 = mysqli_query($conn, "SELECT * FROM pemasukan_harian");
    $jmldata = mysqli_num_rows($query2);
    $jmlhalaman = ceil($jmldata / $batas);

    ?>

    <nav aria-label="Page navigation example">
      <ul class="pagination">
        <?php
            for ($i = 1; $i <= $jmlhalaman; $i++)
                if ($i != $halaman) {
                    echo "<li class='page-item'><a class='page-link' href='Pemasukan Harian.php?halaman=$i'>$i</a></li>";
                } else {
                    echo "<li class='page-item'><a class='page-link'>$i</a></li>";
                }

            ?>
      </ul>
    </nav>

    </body>

    </html>
  </div>
</div>
<?php


mysqli_close($conn);
?>

<?php 
include_once("footer.php");
?>