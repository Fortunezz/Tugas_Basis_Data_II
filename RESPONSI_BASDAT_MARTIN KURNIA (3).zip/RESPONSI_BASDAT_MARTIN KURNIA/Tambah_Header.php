<?php
//Memanggil fungsi agar dapat menjalankan program tertentu
require_once("header.php");
require 'fungsi.php';

//Mengecek apakah data berhasil di tambah
if (isset($_POST["submit"])) {
    if (tambah_header($_POST) > 0) {
        //Jika berhasil, maka akan muncul pesan ini
        echo "
        <script>
            alert('Data berhasil ditambahkan!');
            document.location.href = 'Halaman Header.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan muncul pesan ini
        echo "
		<script>
			alert('Data gagal ditambahkan!');
			document.location.href = 'Halaman Header.php';
		</script>";
    }
}
?>

<?php
include("koneksi.php");
$data = mysqli_query($conn, "SELECT max((no_nota) + 1) as no_no FROM header_bayar");
$row = mysqli_fetch_array($data);

$data1 = mysqli_query($conn, "SELECT max(id_detail) as id_de FROM detail_bayar");
$row1 = mysqli_fetch_array($data1);

?>

<div class="container">
  <div class="main-panel">
    <!--Menampilkan judul untuk web ini-->
    <br>
    <h1 class="display-4">Tambah Data Header</h1>
    <hr>

    <!--Form untuk input data yang akan di tambah-->
    <form class="form-horizontal perhitungan" name="autoSumForm" method="POST" action="">
      <!--Bagian untuk input id merk-->
      <div class="mb-3 row">
        <label for="no_nota" class="col-sm-2 col-form-label">No Nota</label>
        <div class="col-sm-10">
          <input type="text" name="no_nota" class="form-control" id="no_nota" value="<?php echo $row['no_no']; ?>">
        </div>
      </div>

      <!--Bagian untuk input nama merk-->
      <div class="mb-3 row">
        <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
        <div class="col-sm-10">
          <input type="date" name="tanggal" class="form-control" id="tanggal">
        </div>
      </div>

      <!--Bagian untuk input Model Sepatu-->
      <div class="mb-3 row">
        <label for="id_detail" class="col-sm-2 col-form-label">ID Detail</label>
        <div class="col-sm-10">
          <select name="id_detail" id="id_detail" class="form-control">
            <option value="">Pilih Detail</option>
            <?php $row_kost = mysqli_query($conn, "SELECT * FROM sepatu JOIN detail_bayar USING (id_sepatu)");
                        while ($row = mysqli_fetch_array($row_kost)) {
                            echo "<option value='$row[id_detail]'>$row[id_detail]</option>";
                            $harga = ['total_pembayaran'];
                        }
                        mysqli_free_result($row_kost); // untuk penggunaan multiple prosedur
                        mysqli_next_result($conn);
                        ?>
          </select>
        </div>
      </div>

      <!--Bagian untuk input Model Sepatu-->
      <div class="mb-3 row">
        <label for="total_pembelian" class="col-sm-2 col-form-label">Total Pembelian</label>
        <div class="col-sm-10">
          <input type="number" name="total_pembelian" onFocus="startCalc();" onBlur="stopCalc();" class="form-control"
            id="total_pembelian">
        </div>
      </div>

      <!--Bagian untuk input Model Sepatu-->
      <div class="mb-3 row">
        <label for="diskon" class="col-sm-2 col-form-label">Diskon</label>
        <div class="col-sm-10">
          <input type="number" name="diskon" onFocus="startCalc();" onBlur="stopCalc();" class="form-control"
            id="diskon">
        </div>
      </div>

      <!--Bagian untuk input Model Sepatu-->
      <div class="mb-3 row">
        <label for="bayar" class="col-sm-2 col-form-label">bayar</label>
        <div class="col-sm-10">
          <input type="number" name="bayar" onFocus="startCalc();" onBlur="stopCalc();" class="form-control" id="bayar">
        </div>
      </div>

      <!--Bagian untuk input Model Sepatu-->
      <div class="mb-3 row">
        <label for="sisa_bayar" class="col-sm-2 col-form-label"> sisa bayar</label>
        <div class="col-sm-10">
          <input type="number" name="sisa_bayar" class="form-control" id="sisa_bayar">
        </div>
      </div>

      <!--Bagian button untuk submit dan kembali-->
      <hr>
      <button class="btn btn-success" type="submit" name="submit"><span><i class="fa fa-plus-circle"></i> Tambah
          Data</button></a></span>
      <a href="Halaman Header.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
          type="button" class="btn btn-danger">
          <span><i class="fa fa-arrow-left white"></i> Batal</button></span></a>
      <hr>
    </form>
  </div>
</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
  integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
  integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

<script>
function startCalc() {
  interval = setInterval("calc()", 1);
}

function calc() {
  let diskon1 = 0;
  if (diskon1 === 0 || diskon1 === null) {
    bayar1 = document.autoSumForm.bayar.value;
    total_pembelian1 = document.autoSumForm.total_pembelian.value;
    diskon1 = document.autoSumForm.diskon.value;
    document.autoSumForm.sisa_bayar.value = bayar1 - total_pembelian1;
  }
  if (diskon1 >= 1) {
    bayar1 = document.autoSumForm.bayar.value;
    total_pembelian1 = document.autoSumForm.total_pembelian.value;
    diskon1 = document.autoSumForm.diskon.value;
    document.autoSumForm.sisa_bayar.value = bayar1 - (diskon1 * total_pembelian1 / 100);
  }
}

function stopCalc() {
  clearInterval(interval);
}


$(document).ready(function() {
  $('#id_detail').change(function() {
    var id = $(this).val();

    $.ajax({
      type: 'POST', //method
      url: 'DataTotalPembelian.php', //action
      data: {
        id: id
      },
      success: function(data) {
        var isi = JSON.parse(data);
        $('#total_pembelian').val(isi.total_pembayaran);
      }
    });

  });
});
</script>
</body>

</html>


<?php 
      require_once("footer.php");
?>