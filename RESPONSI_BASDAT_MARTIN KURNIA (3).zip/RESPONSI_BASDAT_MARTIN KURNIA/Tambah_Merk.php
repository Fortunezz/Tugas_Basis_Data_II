<?php
//Memanggil fungsi agar dapat menjalankan program tertentu
require_once("header.php");
require 'fungsi.php';

//Mengecek apakah data berhasil di tambah
if (isset($_POST["submit"])) {
    if (tambah_merk($_POST) > 0) {
        //Jika berhasil, maka akan muncul pesan ini
        echo "
        <script>
            alert('Data berhasil ditambahkan!');
            document.location.href = 'Halaman Merk.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan muncul pesan ini
        echo "
		<script>
			alert('Data gagal ditambahkan!');
			document.location.href = 'Tambah_Merk.php';
		</script>";
    }
}
?>
<?php
include("koneksi.php");
$data = mysqli_query($conn, "SELECT max((id_merk) + 1) as id_me FROM merk");
$row = mysqli_fetch_array($data);
?>

<div class="container">
  <div class="main-panel">
    <!--Menampilkan judul untuk web ini-->
    <br>
    <h1 class="display-4">Tambah Data Merk</h1>
    <hr>

    <!--Form untuk input data yang akan di tambah-->
    <form class="form-horizontal" method="POST" action="">
      <!--Bagian untuk input id merk-->
      <div class="mb-3 row">
        <label for="id_merk" class="col-sm-2 col-form-label">ID Merk</label>
        <div class="col-sm-10">
          <input type="text" name="id_merk" class="form-control" id="id_merk" value="<?php echo $row['id_me']; ?>">
        </div>
      </div>

      <!--Bagian untuk input nama merk-->
      <div class="mb-3 row">
        <label for="nama_merk" class="col-sm-2 col-form-label">Nama Merk</label>
        <div class="col-sm-10">
          <input type="text" name="nama_merk" class="form-control" id="nama_merk">
        </div>
      </div>

      <!--Bagian untuk input Model Sepatu-->
      <div class="mb-3 row">
        <label for="model_sepatu" class="col-sm-2 col-form-label">Model Sepatu</label>
        <div class="col-sm-10">
          <input type="text" name="model_sepatu" class="form-control" id="model_sepatu">
        </div>
      </div>

      <!--Bagian button untuk submit dan kembali-->
      <hr>
      <button class="btn btn-success" type="submit" name="submit"><span><i class="fa fa-plus-circle"></i> Tambah
          Data</button></a></span>
      <a href="Halaman Merk.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
          type="button" class="btn btn-danger">
          <span><i class="fa fa-arrow-left white"></i> Batal</button></span></a>
    </form>
  </div>
</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
  integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
  integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
</body>

</html>

<?php 
  require_once("footer.php");
?>