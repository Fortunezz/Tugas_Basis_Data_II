<?php
//memanggil file fungsi untuk menjalankan program
require_once("header.php");
require_once("fungsi.php");

//mengambil id dari url
$id = $_GET["id_merk"];

//mendeklarasikan variable yang berisi query mysql "data sebelum di ubah"
$rows = query("SELECT * FROM merk WHERE id_merk = $id")[0];

//cek apakah input berhasil 
if (isset($_POST["submit"])) {
    if (ubah_merk($_POST) > 0) {
        //Jika berhasil, maka akan menampilkan pesan ini
        echo "
        <script>
            alert('Data berhasil diubah!');
            document.location.href = 'Halaman Merk.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan menampilkan pesan ini
        echo "
		<script>
			alert('Data gagal diubah!');
			document.location.href = 'Ubah_Merk.php';
		</script>";
    }
}
?>
<div class="container">
  <div class="main-panel">
    <!--Menampilkan judul untuk web ini-->
    <br>
    <h1 class="display-4">Ubah Data Merk</h1>
    <hr>

    <!--Form untuk mengubah data pada tabel data merk-->
    <form class="form-horizontal" method="POST" action="">
      <!--Bagian untuk menampilkan id keluarga, tapi tidak terlihat-->
      <input type="hidden" name="id_merk" value="<?= $rows["id_merk"] ?>">

      <!--Bagian input ubah "nama" pada tabel data merk-->
      <div class="row mb-3">
        <label for="nama_merk" class="control-label col-sm-2">Nama Merk</label>
        <div class="col-sm-10">
          <input type="text" name="nama_merk" class="form-control" id="nama" required value="<?= $rows["nama_merk"] ?>">
        </div>
      </div>

      <!--Bagian input ubah "model_sepatu" pada tabel data merk-->
      <div class="row mb-3">
        <label for="model_sepatu" class="control-label col-sm-2">Model Sepatu</label>
        <div class="col-sm-10">
          <input type="text" name="model_sepatu" class="form-control" id="model_sepatu" required
            value="<?= $rows["model_sepatu"] ?>">
        </div>
      </div>


      <!--Bagian input ubah "submit" pada tabel data merk-->
      <hr>
      <button class="btn btn-success" type="submit" name="submit"><span><i class="fa fa-plus-circle"></i> Ubah
          Data</button></a></span>
      <a href="Halaman Merk.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
          type="button" class="btn btn-danger">
          <span><i class="fa fa-arrow-left white"></i> Batal</button></span></a>
    </form>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
  integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
  integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
</body>

</html>

<?php 
require_once("footer.php");
?>