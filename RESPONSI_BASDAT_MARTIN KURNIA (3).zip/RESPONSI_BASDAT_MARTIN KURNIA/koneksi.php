<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$db = '203130503106_toko_sepatu';
// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
// echo "Connected successfully";
?>