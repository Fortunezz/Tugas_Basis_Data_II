<?php
//memanggil file fungsi untuk menjalankan program
require_once("header.php");
require 'fungsi.php';

//mengambil id dari url
$id = $_GET["no_nota"];

//mendeklarasikan variable yang berisi query mysql "data sebelum di ubah"
$rows = query("SELECT * FROM header_bayar WHERE no_nota = $id")[0];

//cek apakah input berhasil 
if (isset($_POST["submit"])) {
    if (ubah_header($_POST) > 0) {
        //Jika berhasil, maka akan menampilkan pesan ini
        echo "
        <script>
            alert('Data berhasil diubah!');
            document.location.href = 'Halaman Header.php';
        </script>";
    } else {
        //Jika tidak berhasil, maka akan menampilkan pesan ini
        echo "
		<script>
			alert('Data gagal diubah!');
			document.location.href = 'Halaman Header.php';
		</script>";
    }
}
?>

<div class="container">
  <div class="main-panel">
    <!--Menampilkan judul untuk web ini-->
    <br>
    <h1 class="display-4">Ubah Data Header Bayar</h1>
    <hr>

    <!--Form untuk mengubah data pada tabel data merk-->
    <form class="form-horizontal" name="autoSumForm" method="POST" action="">
      <!--Bagian untuk menampilkan id keluarga, tapi tidak terlihat-->
      <input type="hidden" name="no_nota" value="<?= $rows["no_nota"] ?>">

      <!--Bagian input ubah "nama" pada tabel data merk-->
      <div class="row mb-3">
        <label for="nama_merk" class="control-label col-sm-2">Tanggal</label>
        <div class="col-sm-10">
          <input type="date" name="tanggal" class="form-control" id="tanggal" required value="<?= $rows["tanggal"] ?>">
        </div>
      </div>

      <input type="hidden" name="id_detail" value="<?= $rows["id_detail"] ?>">

      <!--Bagian input ubah "model_sepatu" pada tabel data merk-->
      <div class="row mb-3">
        <label for="total_pembelian" class="control-label col-sm-2">Total Pembelian</label>
        <div class="col-sm-10">
          <input type="text" name="total_pembelian" class="form-control" id="total_pembelian" onFocus="startCalc();"
            onBlur="stopCalc();" value="<?= $rows["total_pembelian"] ?>">
        </div>
      </div>

      <!--Bagian input ubah "model_sepatu" pada tabel data merk-->
      <div class="row mb-3">
        <label for="bayar" class="control-label col-sm-2">Bayar</label>
        <div class="col-sm-10">
          <input type="text" name="bayar" class="form-control" id="bayar" onFocus="startCalc();" onBlur="stopCalc();"
            value="<?= $rows["bayar"] ?>">
        </div>
      </div>

      <!--Bagian input ubah "model_sepatu" pada tabel data merk-->
      <div class="row mb-3">
        <label for="sisa_bayar" class="control-label col-sm-2">Kembalian</label>
        <div class="col-sm-10">
          <input type="text" name="sisa_bayar" class="form-control" id="sisa_bayar" required
            value="<?= $rows["sisa_bayar"] ?>">
        </div>
      </div>

      <!--Bagian input ubah "submit" pada tabel data merk-->
      <hr>
      <button class="btn btn-success" type="submit" name="submit"><span><i class="fa fa-plus-circle"></i> Ubah
          Data</button></a></span>
      <a href="Halaman Header.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
          type="button" class="btn btn-danger">
          <span><i class="fa fa-arrow-left white"></i> Batal</button></span></a>
      <hr>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
  integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
  integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
</script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

<script>
function startCalc() {
  interval = setInterval("calc()", 1);
}

function calc() {
  bayar1 = document.autoSumForm.bayar.value;
  total_pembelian1 = document.autoSumForm.total_pembelian.value;
  diskon1 = document.autoSumForm.diskon.value;
  document.autoSumForm.sisa_bayar.value = bayar1 - (diskon1 * total_pembelian1 / 100);
}

function stopCalc() {
  clearInterval(interval);
}


$(document).ready(function() {
  $('#id_detail').change(function() {
    var id = $(this).val();

    $.ajax({
      type: 'POST', //method
      url: 'DataTotalPembelian.php', //action
      data: {
        id: id
      },
      success: function(data) {
        var isi = JSON.parse(data);
        $('#total_pembelian').val(isi.total_pembayaran);
      }
    });

  });
});
</script>
</body>

</html>

<?php 
      require_once("footer.php");
    ?>