<?php
//Memanggil fungsi_data_keluarga untuk menjalankan fungsi yang diperlukan
require 'fungsi.php';

//Mengambil id dari url
$id = $_GET["id_detail"];

//Mengecek data berdasarkan id berhasil/tidak
if (hapus_detail($id) > 0) {
	//Jika berhasil, maka akan tampil pesan ini
	echo "
				<script>
					alert('Data berhasil dihapus!');
					document.location.href = 'Halaman Detail.php';
				</script>
		";
} else {
	//Jika gagal, maka akan tampil pesan ini
	echo "
		<script>
					alert('Data gagal dihapus!');
					document.location.href = 'Halaman Detail.php';
				</script>
		";
}