<?php 
include_once("header.php");
require_once("koneksi.php");
require_once("fungsi.php");
// menampilkan total detail menggunakan function
$total_detail = menampilkan_detail();
// menampilkan total merk menggunakan function
$jumlah_merk = menampilkan_total_merk();
// menampilkan total pemasukan menggunakan function
$total_pemasukan = menampilkan_pemasukan();
// menampilkan jenis sepatu menggunakan function
$jumlah_sepatu   = menampilkan_sepatu();
?>


<style>
.card.card-dark-blue {
  background: #2196F3;
  color: #ffffff;
}

.card.card-light-danger {
  background: #673AB7;
  color: #ffffff;
}
</style>
<!-- partial -->
<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
      <div class="col-md-12 grid-margin">
        <div class="row">
          <div class="col-12 col-xl-8 mb-4 mb-xl-0">
            <h3 class="font-weight-bold">Welcome Martin Kurnia</h3>
            <h6 class="font-weight-normal mb-0">Selamat Datang, dihalaman admin <span class="text-primary">
                toko sepatu</span></h6>
          </div>

        </div>
      </div>
    </div>
    <div class="row">
      <div class="container">
        <div class="col-md-12 grid-margin transparent">
          <div class="row">
            <div class="col-md-6 mb-4 stretch-card transparent">
              <div class="card card-tale">
                <div class="card-body">
                  <p class="mb-4">Total Merk</p>
                  <p class="fs-30 mb-5" value="<?php echo $jumlah_merk['total']; ?>">
                    <?php echo $jumlah_merk['total']. " Jenis Merk"; ?>
                  </p>
                  <!-- <p>10.00% (30 days)</p> -->
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-4 stretch-card transparent">
              <div class="card card-dark-blue">
                <div class="card-body">
                  <p class="mb-4">Total Sepatu</p>
                  <p class="fs-30 mb-5" value="<?php echo $jumlah_sepatu['jumlah']; ?>">
                    <?php echo $jumlah_sepatu['jumlah']. " Tipe Sepatu"; ?> </p>
                  <!-- <p>22.00% (30 days)</p> -->
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 mb-4 mb-lg-0 stretch-card transparent">
              <div class="card card-light-blue">
                <div class="card-body">
                  <p class="mb-4">Total Detail</p>
                  <p class="fs-30 mb-5" value="<?php echo $total_detail['total']; ?>">
                    <?php echo $total_detail['total']. " Jenis Detail"; ?></p>
                  <!-- <p>2.00% (30 days)</p> -->
                </div>
              </div>
            </div>
            <div class="col-md-6 stretch-card transparent">
              <div class="card card-light-danger">
                <div class="card-body">
                  <p class="mb-4">Total Pemasukan</p>
                  <p class="fs-30 mb-5" value="<?php echo $total_pemasukan['total']; ?>">Rp.
                    <?php echo number_format($total_pemasukan['total']); ?> </p>
                  <!-- <p>0.22% (30 days)</p> -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php  
include_once("footer.php");
?>