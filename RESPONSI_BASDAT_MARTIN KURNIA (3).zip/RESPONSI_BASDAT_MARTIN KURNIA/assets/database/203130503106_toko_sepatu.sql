-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2023 at 01:38 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `203130503106_toko_sepatu`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `BanyakTransaksi` ()  BEGIN
SELECT COUNT(total_pembelian) AS 'Total_pembelian'
FROM header_bayar;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteDataDetail` (`del_id_detail` INT(12))  BEGIN
DELETE FROM detail_bayar WHERE id_detail=del_id_detail; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteDataHeader` (`del_no_nota` INT(12))  BEGIN
DELETE FROM header_bayar WHERE no_nota=del_no_nota; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteDataMerk` (`del_id_merk` INT(12))  BEGIN
DELETE FROM merk WHERE id_merk = del_id_merk; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DeleteDataSepatu` (`del_id_sepatu` INT(12))  BEGIN
DELETE FROM sepatu WHERE id_sepatu = del_id_sepatu; END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `HitungTotalPembelian` ()  BEGIN
SELECT SUM(total_pembelian) AS 'Total Pembelian' FROM header_bayar;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `HitungTotalPembelian2` (`NO` INT(3))  BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING, NOT FOUND ROLLBACK;
SELECT SUM(total_pembelian) FROM header_bayar WHERE no_nota=NO;
COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `MasukDataDetail` (`id_detail` INT(12), `id_sepatu` INT(12), `jumlah_beli` INT(12))  BEGIN
INSERT INTO detail_bayar (id_detail,id_sepatu,jumlah_beli) VALUES (id_detail,id_sepatu,jumlah_beli);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `MasukDataHeader` (`no_nota` INT(12), `tanggal` DATE, `id_detail` INT(12), `total_pembelian` INT(20), `bayar` INT(40), `sisa_bayar` INT(40))  BEGIN
INSERT INTO header_bayar (no_nota,tanggal,id_detail,total_pembelian,bayar,sisa_bayar)
VALUES
(no_nota,tanggal,id_detail,total_pembelian,bayar,sisa_bayar); END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `MasukDataMerk` (`id_merk` INT(12), `nama_merk` VARCHAR(40), `model_sepatu` VARCHAR(40))  BEGIN
INSERT INTO merk (id_merk,nama_merk,model_sepatu)
VALUES (id_merk,nama_merk,model_sepatu);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `MasukDataSepatu` (`id_sepatu` INT(12), `id_merk` INT(12), `ukuran` INT(30), `warna` VARCHAR(40), `harga` INT(40), `stok` INT(40))  BEGIN
INSERT INTO sepatu (id_sepatu,id_merk,ukuran,warna,harga,stok) VALUES (id_sepatu,id_merk,ukuran,warna,harga,stok);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SepatuBanyakDibeli` ()  BEGIN
select nama_merk as 'Merk_Sepatu', jumlah_beli as 'Paling Banyak Dibeli'
       from detail_bayar
       join sepatu on detail_bayar.id_sepatu = sepatu.id_sepatu
       JOIN merk ON sepatu.id_merk = merk.id_merk
WHERE jumlah_beli = (select max(jumlah_beli) from detail_bayar); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SepatuPalingMahal` ()  BEGIN
SELECT nama_merk AS 'Merk_Sepatu', harga AS 'Sepatu harga termahal'
       FROM sepatu
       JOIN merk ON sepatu.id_merk = merk.id_merk
WHERE harga = (SELECT MAX(harga) FROM sepatu); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SepatuPalingMurah` ()  BEGIN
SELECT nama_merk AS 'Merk_Sepatu', harga AS 'Sepatu harga termurah'
       FROM sepatu
       JOIN merk ON sepatu.id_merk = merk.id_merk
WHERE harga = (SELECT Min(harga) FROM sepatu); 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `TotalPembelianOtomatis` (IN `par` INT(11))  BEGIN
	  SELECT SUM(sepatu.harga * detail_bayar.jumlah_beli) as total_pembayaran
	  FROM merk
	  JOIN sepatu ON merk.id_merk = sepatu.id_merk
	  JOIN detail_bayar ON sepatu.id_sepatu = detail_bayar.id_sepatu
	  WHERE detail_bayar.id_detail = par;
	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateDataDetail` (IN `id_details` INT(12), IN `jumlah_belis` INT(12))  BEGIN
UPDATE detail_bayar
SET jumlah_beli = jumlah_belis WHERE id_detail = id_details;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateDataHeader` (IN `no_nota_up` INT(3), IN `tanggalnya` DATE, IN `total_pembeliannya` VARCHAR(11), IN `up_bayar` VARCHAR(35), IN `upsisabayar` VARCHAR(35))  BEGIN
UPDATE header_bayar SET tanggal = tanggalnya,total_pembelian = total_pembeliannya, bayar = up_bayar, sisa_bayar = upsisabayar
	WHERE no_nota = no_nota_up;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateDataMerk` (IN `id_merks` INT(12), IN `nama_merks` VARCHAR(12), IN `model_sepatus` VARCHAR(30))  BEGIN
UPDATE merk
SET nama_merk = nama_merks, model_sepatu = model_sepatus WHERE id_merk = id_merks;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateDataSepatu` (IN `up_idsepatu` INT(4), IN `up_ukuran` INT(2), IN `up_warna` VARCHAR(10), IN `up_harga` VARCHAR(35), IN `upstok` INT(10))  BEGIN
UPDATE sepatu SET ukuran = up_ukuran, warna=up_warna, harga=up_harga,stok=upstok
	WHERE id_sepatu = up_idsepatu;
	 END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `BuatNoNota` (`Nomor` VARCHAR(10)) RETURNS VARCHAR(10) CHARSET utf8mb4 BEGIN
DECLARE tgl VARCHAR(10);
DECLARE bln VARCHAR(10);
DECLARE thn VARCHAR(10);
DECLARE id VARCHAR(10);
    SELECT TRIM(SUBSTRING(tanggal,9,2)) INTO tgl FROM header_bayar WHERE no_nota=Nomor;
    SELECT TRIM(SUBSTRING(tanggal,6,2)) INTO bln FROM header_bayar WHERE no_nota=Nomor;
    SELECT TRIM(SUBSTRING(tanggal,3,2)) INTO thn FROM header_bayar WHERE no_nota=Nomor;
    SELECT TRIM(SUBSTRING(no_nota,2,2)) INTO id FROM header_bayar WHERE no_nota=Nomor;
    RETURN CONCAT(thn,bln,tgl,'-',id);
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `PenghasilanHarian` (`tgl` DATE) RETURNS INT(11) BEGIN
DECLARE total INT;
SELECT SUM(`detail_bayar`.`jumlah_beli`*`sepatu`.`harga`) INTO total FROM detail_bayar,header_bayar,sepatu
WHERE `detail_bayar`.`id_detail`=`header_bayar`.`id_detail` AND `detail_bayar`.`id_sepatu`=`sepatu`.`id_sepatu`
AND `header_bayar`.`tanggal`=tgl; RETURN total;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `SisaBayarSepatu` (`id_detail` INT) RETURNS INT(11) BEGIN
	  DECLARE sisa INT;
	  SELECT SUM(header_bayar.bayar - header_bayar.total_pembelian) AS sisa_bayar INTO sisa
	  FROM merk
	  JOIN sepatu ON merk.id_merk = sepatu.id_merk
	  JOIN detail_bayar ON sepatu.id_sepatu = detail_bayar.id_sepatu
	  JOIN header_bayar ON detail_bayar.id_detail = header_bayar.id_detail
	  WHERE header_bayar.id_detail = id_detail;

	  RETURN sisa;

    END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `TotalPembelianSepatu` (`id_detail` INT) RETURNS INT(11) BEGIN
	  DECLARE total INT;
	  SELECT SUM(sepatu.harga * detail_bayar.jumlah_beli) as total into total
	  FROM merk
	  JOIN sepatu ON merk.id_merk = sepatu.id_merk
	  JOIN detail_bayar ON sepatu.id_sepatu = detail_bayar.id_sepatu
	  WHERE detail_bayar.id_detail = id_detail;
	  
	  RETURN total;

    END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `detail_bayar`
--

CREATE TABLE `detail_bayar` (
  `id_detail` int(12) NOT NULL,
  `id_sepatu` int(12) NOT NULL,
  `jumlah_beli` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_bayar`
--

INSERT INTO `detail_bayar` (`id_detail`, `id_sepatu`, `jumlah_beli`) VALUES
(1, 11, 1),
(2, 12, 1),
(3, 13, 1),
(4, 14, 2),
(6, 13, 2),
(7, 16, 7),
(8, 15, 2),
(9, 17, 2);

--
-- Triggers `detail_bayar`
--
DELIMITER $$
CREATE TRIGGER `EditStok` AFTER INSERT ON `detail_bayar` FOR EACH ROW BEGIN
        update sepatu set stok = stok-NEW.jumlah_beli
        where id_sepatu = NEW.id_sepatu;
    END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UpdateStok` AFTER UPDATE ON `detail_bayar` FOR EACH ROW BEGIN
	update sepatu set stok = stok+(OLD.jumlah_beli - NEW.jumlah_beli)
        WHERE id_sepatu = NEW.id_sepatu;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `header_bayar`
--

CREATE TABLE `header_bayar` (
  `no_nota` int(12) NOT NULL,
  `tanggal` date NOT NULL,
  `id_detail` int(12) NOT NULL,
  `total_pembelian` float NOT NULL,
  `bayar` float NOT NULL,
  `sisa_bayar` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `header_bayar`
--

INSERT INTO `header_bayar` (`no_nota`, `tanggal`, `id_detail`, `total_pembelian`, `bayar`, `sisa_bayar`) VALUES
(11, '2023-03-01', 1, 400000, 400000, 0),
(12, '2023-03-02', 2, 300000, 300000, 0),
(13, '2023-03-24', 2, 250000, 250000, 0),
(14, '2023-03-25', 4, 1200000, 1200000, 0),
(16, '2023-03-26', 3, 200000, 200000, 0),
(17, '2023-04-01', 7, 2800000, 2800000, 0),
(18, '2023-04-01', 8, 500000, 500000, 0),
(19, '2023-04-02', 8, 50000, 100000, 55000);

--
-- Triggers `header_bayar`
--
DELIMITER $$
CREATE TRIGGER `HapusDetailBayar` AFTER DELETE ON `header_bayar` FOR EACH ROW BEGIN
        delete detail_bayar from detail_bayar where id_detail = old.id_detail;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `menampilkan_merk`
-- (See below for the actual view)
--
CREATE TABLE `menampilkan_merk` (
`id_merk` int(12)
,`nama_merk` varchar(40)
,`model_sepatu` varchar(40)
);

-- --------------------------------------------------------

--
-- Table structure for table `merk`
--

CREATE TABLE `merk` (
  `id_merk` int(12) NOT NULL,
  `nama_merk` varchar(40) NOT NULL,
  `model_sepatu` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `merk`
--

INSERT INTO `merk` (`id_merk`, `nama_merk`, `model_sepatu`) VALUES
(1, 'Jordan', 'Livid'),
(2, 'Reebok', 'White'),
(3, 'Ardiles', 'Sneakers'),
(4, 'Nikke', 'Aero'),
(5, 'Ando', 'Sneakers'),
(6, 'Piero', 'Sneakers'),
(7, 'Puma', 'Sneakers');

--
-- Triggers `merk`
--
DELIMITER $$
CREATE TRIGGER `HapusDataSepatu` BEFORE DELETE ON `merk` FOR EACH ROW BEGIN
	DECLARE id_merk INT;
	DECLARE id_sepatu INT;
	DECLARE id_detail INT;
	DECLARE no_nota INT;
	
	SELECT OLD.id_merk INTO id_merk;
    
	SELECT sepatu.id_sepatu INTO id_sepatu 
	FROM sepatu 
	INNER JOIN merk ON sepatu.id_merk = merk.id_merk
	WHERE merk.id_merk = id_merk;
    
	SELECT detail_bayar.id_detail INTO id_detail 
	FROM detail_bayar 
	INNER JOIN sepatu ON detail_bayar.id_sepatu = sepatu.id_sepatu
	INNER JOIN merk ON sepatu.id_merk = merk.id_merk
	WHERE merk.id_merk = id_merk;
            
	SELECT header_bayar.no_nota INTO no_nota 
	FROM header_bayar 
	INNER JOIN detail_bayar ON header_bayar.id_detail = detail_bayar.id_detail
	INNER JOIN sepatu ON detail_bayar.id_sepatu = sepatu.id_sepatu
	INNER JOIN merk ON sepatu.id_merk = merk.id_merk
	WHERE merk.id_merk = id_merk;
    
	CALL DeleteDataHeader(no_nota);
	CALL DeleteDataDetail(id_detail);
	CALL DeleteDataSepatu(id_sepatu);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `pemasukan_harian`
-- (See below for the actual view)
--
CREATE TABLE `pemasukan_harian` (
`No Nota` int(12)
,`Tanggal` date
,`Total Pembelian` double
);

-- --------------------------------------------------------

--
-- Table structure for table `sepatu`
--

CREATE TABLE `sepatu` (
  `id_sepatu` int(12) NOT NULL,
  `id_merk` int(12) NOT NULL,
  `ukuran` int(30) NOT NULL,
  `warna` varchar(40) NOT NULL,
  `harga` float NOT NULL,
  `stok` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sepatu`
--

INSERT INTO `sepatu` (`id_sepatu`, `id_merk`, `ukuran`, `warna`, `harga`, `stok`) VALUES
(11, 1, 42, 'Navy', 400000, 1),
(12, 2, 42, 'White', 300000, 4),
(13, 3, 42, 'Blue', 200000, 1),
(14, 4, 42, 'Purple', 600000, 0),
(15, 5, 42, 'Black', 250000, 3),
(16, 6, 42, 'Red', 350000, 13),
(17, 7, 42, 'Pink', 400000, 7),
(18, 7, 42, 'BLUE OLD', 150000, 10);

-- --------------------------------------------------------

--
-- Stand-in structure for view `sepatu_puma`
-- (See below for the actual view)
--
CREATE TABLE `sepatu_puma` (
`nama_merk` varchar(40)
,`model_sepatu` varchar(40)
,`ukuran` int(30)
,`warna` varchar(40)
,`harga` float
);

-- --------------------------------------------------------

--
-- Structure for view `menampilkan_merk`
--
DROP TABLE IF EXISTS `menampilkan_merk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `menampilkan_merk`  AS   (select `merk`.`id_merk` AS `id_merk`,`merk`.`nama_merk` AS `nama_merk`,`merk`.`model_sepatu` AS `model_sepatu` from `merk`)  ;

-- --------------------------------------------------------

--
-- Structure for view `pemasukan_harian`
--
DROP TABLE IF EXISTS `pemasukan_harian`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pemasukan_harian`  AS   (select `header_bayar`.`no_nota` AS `No Nota`,`header_bayar`.`tanggal` AS `Tanggal`,sum(`header_bayar`.`total_pembelian`) AS `Total Pembelian` from `header_bayar` group by `header_bayar`.`tanggal`)  ;

-- --------------------------------------------------------

--
-- Structure for view `sepatu_puma`
--
DROP TABLE IF EXISTS `sepatu_puma`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sepatu_puma`  AS   (select `m`.`nama_merk` AS `nama_merk`,`m`.`model_sepatu` AS `model_sepatu`,`s`.`ukuran` AS `ukuran`,`s`.`warna` AS `warna`,`s`.`harga` AS `harga` from (`merk` `m` join `sepatu` `s` on(`m`.`id_merk` = `s`.`id_merk`)) where `m`.`nama_merk` = 'Puma')  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detail_bayar`
--
ALTER TABLE `detail_bayar`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `detail_bayar_ibfk_1` (`id_sepatu`);

--
-- Indexes for table `header_bayar`
--
ALTER TABLE `header_bayar`
  ADD PRIMARY KEY (`no_nota`),
  ADD KEY `header_bayar_ibfk_1` (`id_detail`);

--
-- Indexes for table `merk`
--
ALTER TABLE `merk`
  ADD PRIMARY KEY (`id_merk`);

--
-- Indexes for table `sepatu`
--
ALTER TABLE `sepatu`
  ADD PRIMARY KEY (`id_sepatu`),
  ADD KEY `sepatu_ibfk_1` (`id_merk`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_bayar`
--
ALTER TABLE `detail_bayar`
  ADD CONSTRAINT `detail_bayar_ibfk_2` FOREIGN KEY (`id_sepatu`) REFERENCES `sepatu` (`id_sepatu`);

--
-- Constraints for table `header_bayar`
--
ALTER TABLE `header_bayar`
  ADD CONSTRAINT `header_bayar_ibfk_2` FOREIGN KEY (`id_detail`) REFERENCES `detail_bayar` (`id_detail`);

--
-- Constraints for table `sepatu`
--
ALTER TABLE `sepatu`
  ADD CONSTRAINT `sepatu_ibfk_2` FOREIGN KEY (`id_merk`) REFERENCES `merk` (`id_merk`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
